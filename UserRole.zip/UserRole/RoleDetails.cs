﻿using UserDetailsRepo.Interfaces;

namespace UserDetailsRepo
{
    public class RoleDetails : IRoleDetails
    {
        public List<int> RoleId = new() { 1, 2, 3 };
        public int roleId = 0;
        public string userName = string.Empty;
        public void GetRoleID(int role_id)
        {
            roleId = role_id;
        }

        public void GetUserName(string user_name)
        {
            userName= user_name;
        }
        public bool VerifyRole() 
        {
            if (RoleId.Contains(roleId))
                return true;
            else
                return false;

        }
        public string AddRole(bool isAvailable)
        {
            if (isAvailable)
                return "Role Added Succesfully";
            else
                return "RoleId: " + roleId + " is not available for mappping";
        }
    }
}
