﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDetailsRepo.Interfaces
{
    public interface IUserDetails
    {
        void GetUserName(string name);
        void GetEmail(string email_id);
        bool CheckEmail();
        string AddEmail(bool IsEmail);
        string VerifyUserAndAdd();
    }
}
