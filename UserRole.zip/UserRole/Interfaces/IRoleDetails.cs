﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDetailsRepo.Interfaces
{
    public interface IRoleDetails
    {
        void GetRoleID(int role_id);
        void GetUserName(string user_name);
        bool VerifyRole();
        string AddRole(bool IsAvailable);
    }
}
