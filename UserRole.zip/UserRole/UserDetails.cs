﻿using System.Text.RegularExpressions;
using UserDetailsRepo.Interfaces;

namespace UserRole
{
    public class UserDetails: IUserDetails
    {
        public string user_name= string.Empty;
        public  string email = string.Empty;
        bool Is_Email;
        public void GetUserName(string name) 
        { 
            user_name= name;
        }
        public void GetEmail(string email_id) { email = email_id; }
        public string VerifyUserAndAdd() 
        {
            if (Regex.IsMatch(user_name, @"^[a-zA-Z]+$") )
                return "Details are added Successfully";
            else
                return "Details are not added";
        }

        public bool CheckEmail()
        {
            if (Regex.IsMatch(email, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$"))
                return true;
            else
                return false;
        }
        public string AddEmail(bool IsEmail) 
        {
            if (IsEmail)
                return "Email Added Succesfully";
            else
                return "Email Adding failed";
        }
    }
}
