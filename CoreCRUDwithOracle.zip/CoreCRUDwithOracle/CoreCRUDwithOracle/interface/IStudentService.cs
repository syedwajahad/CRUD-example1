﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CoreCRUDwithOracle.Models;
using System.Collections.Generic;
namespace CoreCRUDwithOracle.Interface
{
    public interface IStudentService
    {
        IEnumerable<Student> GetAllStudent();
        Student GetStudentById(int eid);
        void AddStudent(Student student);
        void EditStudent(Student student);
        void DeleteStudent(Student student);
    }
}