﻿
    var myapp = angular.module('myapp', []);
myapp.controller('mycontroller', function ($scope) {
    $scope.employees = [];
    $scope.AddDetails = function (employee)
    {

        $scope.employees.push(employee);
        $scope.employee = '';

    }
    $scope.DeleteDetails = function (employee)
    {

        $scope.employees.splice($scope.employees.indexOf(employee), 1)
    }
    $scope.EditDetails=function(employee)
    {
        $scope.employee = employee;

    }

    $scope.UpdateData = function () {
        $scope.employee = '';
    }

    //ClearModel();

    function ClearModel() {
        $scope.employees.Name = '';
        $scope.employees.Email = '';
        $scope.employees.Location = 0;
    }



});
