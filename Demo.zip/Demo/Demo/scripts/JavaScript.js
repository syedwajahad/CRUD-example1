﻿/// <reference path="JavaScript.js" />

var app = angular
        .module("myModule", [])
        .controller("myController", function ($scope, $http) {

            $http.get("Employeeservice.asmx/GetAllEmployees")
                 .then(function (response) {
                     $scope.employees = response.data;
                 });
        });
function productDelete(ctl) {
    var id = $(ctl).data("id");

    $.ajax({
        url: "Employeeservice.asmx/DeleteEmployees" + id,
        type: 'DELETE',
        success: function (product) {
            $(ctl).parents("tr").remove();
        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}
      

