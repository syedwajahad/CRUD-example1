using System;
using TechTalk.SpecFlow;
using UserDetailsRepo;
using UserDetailsRepo.Interfaces;
using UserRole;

namespace SpecFlowProjectUserRole.StepDefinitions
{
    [Binding]
    public class RoleVerificationStepDefinitions
    {
        private readonly IRoleDetails _roledetails = new RoleDetails();
        private readonly ScenarioContext _scenarioContext;

        public bool _result;
        public string output;
        public RoleVerificationStepDefinitions(ScenarioContext scenarioContext)
        {
                _scenarioContext = scenarioContext;
        }
        [Given(@"the roleid is (.*)")]
        public void GivenTheRoleidIs(int role_id)
        {
            _roledetails.GetRoleID(role_id);
        }

        [Given(@"the user_name is (.*)")]
        public void GivenTheUser_NameIsJohnDoe(string user_name)
        {
            _roledetails.GetUserName(user_name);
        }

        [When(@"I Check if RoleId is available")]
        public void WhenTheRoleDetailsAreAdded()
        {
            _result = _roledetails.VerifyRole();
        }
        [Then(@"the output should be (.*)")]
        public void ThenTheOutputShouldBe(string result) 
        {
            output = _roledetails.AddRole(_result);
            output.Should().Be(result);
        }
    }
}
