using Microsoft.VisualStudio.TestPlatform.Utilities;
using UserDetailsRepo;
using UserDetailsRepo.Interfaces;
using UserRole;

namespace SpecFlowProjectUserRole.StepDefinitions
{
    [Binding]
    public sealed class UserVerificationStepDefinitions
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef
        private readonly IUserDetails _userdetails= new UserDetails();
        private readonly ScenarioContext _scenarioContext;

        public string _result;
        public bool IsEmail;
        public string output;
        public UserVerificationStepDefinitions(ScenarioContext scenarioContext)
        {
           _scenarioContext= scenarioContext; 
        }

        [Given("the username is (.*)")]
        public void GivenTheUserNameIs(string user_name)
        {
            _userdetails.GetUserName(user_name);
            //throw new PendingStepException();
        }


        [Given("the email is (.*)")]
        public void GivenTheEmailIs(string Email)
        {
            //TODO: implement arrange (precondition) logic
            _userdetails.GetEmail(Email);
            //throw new PendingStepException();
        }

        [When("the details are added")]
        public void VerifyTheUser()
        {
            //TODO: implement act (action) logic
            _result= _userdetails.VerifyUserAndAdd();
            //throw new PendingStepException();
        }
        [When("Check if we can add the Email")]
        public void VerifyTheEmail()
        {
            IsEmail = _userdetails.CheckEmail();
        }
        [Then("the result should be (.*)")]
        public void ThenTheResultShouldBe(string result)
        {
            //TODO: implement assert (verification) logic
            _result.Should().Be(result);
            // throw new PendingStepException();
        }
        [Then("the output of adding email should be (.*)")]
        public void ThenTheResulttoAddEmailShouldBe(string result)
        {
            //TODO: implement assert (verification) logic
            output = _userdetails.AddEmail(IsEmail);
            output.Should().Be(result);
            // throw new PendingStepException();
        }
    }
}
